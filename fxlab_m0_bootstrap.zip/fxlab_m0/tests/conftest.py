"""Shared pytest fixtures for all test types.

Unit tests: all external I/O mocked.
Integration tests: require Docker Compose stack (marked @pytest.mark.integration).
"""
import pytest


@pytest.fixture
def correlation_id() -> str:
    """A fixed correlation ID for deterministic test assertions."""
    return "test-correlation-id-00000000"
