"""FXLab test suite."""
