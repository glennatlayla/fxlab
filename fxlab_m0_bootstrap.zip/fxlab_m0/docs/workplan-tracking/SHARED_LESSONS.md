# FXLab Shared Lessons (cross-phase)
# Promote lessons here when Apply-to spans 2+ phases.
# Last updated: 2026-03-14T15:41:14Z
#
# Format:
#   LL-SNNN  Title
#   Source workplan + ISS ref
#   Lesson text
#   Apply to: All phases / Phase N+

---
# LL-S001
# Title:     <shared lesson title>
# Milestone: <originating milestone>
# Source:    <ISS-NNN from which workplan>
# Lesson:    <lesson>
# Apply to:  All phases
