"""Base Pydantic models and API envelope used across all contracts."""
from __future__ import annotations

from typing import Any, Generic, TypeVar
from pydantic import BaseModel, ConfigDict, field_validator
from datetime import datetime, timezone

T = TypeVar("T")


class FXLabBaseModel(BaseModel):
    """Base class for all FXLab Pydantic models.

    Enforces:
    - ORM mode enabled (from_attributes)
    - No extra fields allowed
    - Strict types
    """
    model_config = ConfigDict(
        from_attributes=True,
        extra="forbid",
        strict=False,  # coerce where safe (e.g. str -> Enum)
        populate_by_name=True,
    )


class APIError(FXLabBaseModel):
    """Structured error payload returned in the response envelope."""
    code: str
    message: str
    details: dict[str, Any] | None = None


class APIMeta(FXLabBaseModel):
    """Metadata included in every API response."""
    correlation_id: str
    api_version: str = "v1"
    timestamp: datetime = datetime.now(timezone.utc)


class APIResponse(BaseModel, Generic[T]):
    """Standard API response envelope.

    Success:  {"data": <T>, "meta": {...}, "error": null}
    Failure:  {"data": null, "meta": {...}, "error": {...}}
    """
    data: T | None = None
    meta: APIMeta
    error: APIError | None = None

    @classmethod
    def ok(cls, data: T, correlation_id: str) -> "APIResponse[T]":
        return cls(data=data, meta=APIMeta(correlation_id=correlation_id))

    @classmethod
    def fail(cls, code: str, message: str, correlation_id: str,
             details: dict[str, Any] | None = None) -> "APIResponse[None]":
        return cls(
            data=None,
            meta=APIMeta(correlation_id=correlation_id),
            error=APIError(code=code, message=message, details=details),
        )
