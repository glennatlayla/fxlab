"""Typed exceptions for FXLab.

All exceptions inherit from FXLabError so callers can catch the
base type or the specific subtype. Each exception carries an
API error code that maps directly to the APIError.code field.
"""


class FXLabError(Exception):
    """Base exception for all FXLab domain errors."""
    code: str = "FXLAB_ERROR"

    def __init__(self, message: str, details: dict | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.details = details or {}


class NotFoundError(FXLabError):
    """Resource not found."""
    code = "NOT_FOUND"


class ConflictError(FXLabError):
    """State conflict — e.g. duplicate idempotency key."""
    code = "CONFLICT"


class ValidationError(FXLabError):
    """Input failed domain validation."""
    code = "VALIDATION_ERROR"


class AuthenticationError(FXLabError):
    """Invalid or missing credentials."""
    code = "AUTHENTICATION_REQUIRED"


class AuthorizationError(FXLabError):
    """Insufficient permissions."""
    code = "FORBIDDEN"


class ExternalServiceError(FXLabError):
    """Transient failure from an external dependency (retriable)."""
    code = "EXTERNAL_SERVICE_ERROR"


class StorageError(FXLabError):
    """Object storage read/write failure."""
    code = "STORAGE_ERROR"


class QueueError(FXLabError):
    """Job queue / broker failure."""
    code = "QUEUE_ERROR"


class DataQualityError(FXLabError):
    """Data failed quality checks and was quarantined."""
    code = "DATA_QUALITY_ERROR"


class FeedConfigError(FXLabError):
    """Feed configuration is invalid or incomplete."""
    code = "FEED_CONFIG_INVALID"
