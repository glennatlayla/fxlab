"""Centralised enum definitions for all FXLab domain objects.

All enums live here so they can be imported by any layer without
introducing circular dependencies.
"""
from enum import StrEnum


class FeedLifecycleStatus(StrEnum):
    DRAFT = "draft"
    ACTIVE = "active"
    DISABLED = "disabled"
    RETIRED = "retired"


class FeedConfigStatus(StrEnum):
    DRAFT = "draft"
    ACTIVE = "active"
    SUPERSEDED = "superseded"


class DatasetStatus(StrEnum):
    PENDING = "pending"
    PROCESSING = "processing"
    READY = "ready"
    FAILED = "failed"


class CertificationState(StrEnum):
    PENDING = "pending"
    CERTIFIED = "certified"
    QUARANTINED = "quarantined"
    SUPERSEDED = "superseded"


class GapSeverity(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class AnomalySeverity(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ParityStatus(StrEnum):
    CLEAN = "clean"
    BREACH = "breach"
    ERROR = "error"


class AlertSeverity(StrEnum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class JobStatus(StrEnum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    RETRYING = "retrying"
    CANCELLED = "cancelled"


class QueueClass(StrEnum):
    DEFAULT = "default"
    INGEST = "ingest"
    VERIFICATION = "verification"
    PARITY = "parity"
    BACKFILL = "backfill"


class PermissionCode(StrEnum):
    FEED_READ = "feed.read"
    FEED_WRITE = "feed.write"
    FEED_DISABLE = "feed.disable"
    FEED_RETIRE = "feed.retire"
    FEED_TEST_CONNECTIVITY = "feed.test_connectivity"
    FEED_VALIDATE = "feed.validate"
    FEED_BACKFILL = "feed.backfill"
    DATA_READ = "data.read"
    DATA_CERTIFY = "data.certify"
    DATA_QUARANTINE = "data.quarantine"
    DATA_LINEAGE_READ = "data.lineage.read"
    PARITY_READ = "parity.read"
    PARITY_RUN = "parity.run"
    QUEUE_READ = "queue.read"
    AUDIT_READ = "audit.read"
    ARTIFACT_READ = "artifact.read"
    PLATFORM_HEALTH_READ = "platform.health.read"
    ADMIN_MANAGE = "admin.manage"
