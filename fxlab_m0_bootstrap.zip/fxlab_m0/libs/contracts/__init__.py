"""FXLab shared contracts — Pydantic v2 models, enums, and API schemas.

This package is the innermost layer of the onion architecture.
It has ZERO external dependencies beyond pydantic and stdlib.
All other packages import from here; this package imports from nothing internal.
"""
