"""feed_parity service — stub for Phase 1 implementation."""
