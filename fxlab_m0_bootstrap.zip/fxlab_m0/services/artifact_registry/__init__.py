"""artifact_registry service — stub for Phase 1 implementation."""
