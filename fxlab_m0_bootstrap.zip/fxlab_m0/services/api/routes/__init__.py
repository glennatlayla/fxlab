"""API route handlers — thin controllers only, no business logic."""
