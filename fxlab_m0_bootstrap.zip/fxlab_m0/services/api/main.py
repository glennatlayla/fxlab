"""FXLab API service entry point.

Spin up with:
    uvicorn services.api.main:app --reload --port 8000
"""
from fastapi import FastAPI

app = FastAPI(
    title="FXLab API",
    version="0.1.0",
    description="FXLab platform — Phase 1 operator API",
    docs_url="/docs",
    redoc_url="/redoc",
)


@app.get("/health", tags=["platform"])
async def health() -> dict:
    """Basic liveness probe — returns 200 when the process is alive."""
    return {"status": "ok", "service": "api"}


@app.get("/health/dependencies", tags=["platform"])
async def health_dependencies() -> dict:
    """Dependency readiness probe — stub for Phase 1."""
    return {
        "status": "degraded",
        "dependencies": {
            "postgres": "unknown",
            "redis": "unknown",
            "minio": "unknown",
        },
        "note": "Implement in M1 after Docker Compose stack is running.",
    }
