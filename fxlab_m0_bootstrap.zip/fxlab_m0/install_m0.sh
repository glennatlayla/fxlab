#!/usr/bin/env bash
# install_m0.sh — M0 Bootstrap installer
# Run from the fxlab project root:
#   cd /path/to/fxlab && bash install_m0.sh
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STEM="FXLab_Phase_1_workplan_v3"
TRACKING="$ROOT/docs/workplan-tracking"

echo ""
echo "=== FXLab M0 Bootstrap ==="
echo "Project root: $ROOT"
echo ""

# ── 1. Create directory tree ─────────────────────────────────────────────────
echo "Creating directory tree..."
dirs=(
  "docs/workplan-tracking" "docs/phases" "docs/api" "docs/adr"
  "User Spec"
  "services/api/routes" "services/auth" "services/orchestrator"
  "services/scheduler" "services/market_data_ingest" "services/feed_verification"
  "services/feed_parity" "services/artifact_registry" "services/alerting"
  "services/observability"
  "libs/contracts" "libs/db" "libs/authz" "libs/storage"
  "libs/feeds" "libs/datasets" "libs/audit" "libs/jobs"
  "libs/quality" "libs/parity" "libs/telemetry" "libs/utils"
  "infra/compose" "infra/docker" "infra/migrations" "infra/observability"
  "tests/unit/controllers" "tests/unit/services" "tests/unit/repositories"
  "tests/integration" "tests/acceptance" "tests/fixtures"
)
for d in "${dirs[@]}"; do
  mkdir -p "$ROOT/$d"
done
echo "  OK: directories created"

# ── 2. Update .active_workplan with correct absolute-agnostic paths ──────────
echo "Updating .active_workplan..."
cat > "$TRACKING/.active_workplan" << JSON
{
  "workplan_stem": "$STEM",
  "workplan_path": "User Spec/${STEM}.md",
  "spec_path": "User Spec/phase_1_platform_foundation_v1.md"
}
JSON
echo "  OK: .active_workplan written"

# ── 3. Copy files from this archive to the project ──────────────────────────
echo "Copying files..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

copy_if_new() {
  local src="$1" dst="$2"
  if [ -f "$dst" ]; then
    echo "  SKIP (exists): $dst"
  else
    cp "$src" "$dst"
    echo "  OK: $dst"
  fi
}

# Tracking files — always overwrite (they were empty stubs)
cp "$SCRIPT_DIR/docs/workplan-tracking/${STEM}.progress"        "$TRACKING/${STEM}.progress"
cp "$SCRIPT_DIR/docs/workplan-tracking/${STEM}.issues"          "$TRACKING/${STEM}.issues"
cp "$SCRIPT_DIR/docs/workplan-tracking/${STEM}.lessons-learned" "$TRACKING/${STEM}.lessons-learned"
cp "$SCRIPT_DIR/docs/workplan-tracking/SHARED_LESSONS.md"       "$TRACKING/SHARED_LESSONS.md"
echo "  OK: tracking files"

# Root files
copy_if_new "$SCRIPT_DIR/pyproject.toml"   "$ROOT/pyproject.toml"
copy_if_new "$SCRIPT_DIR/.gitignore"       "$ROOT/.gitignore"
copy_if_new "$SCRIPT_DIR/.env.example"     "$ROOT/.env.example"

# libs/contracts
copy_if_new "$SCRIPT_DIR/libs/contracts/__init__.py"  "$ROOT/libs/contracts/__init__.py"
copy_if_new "$SCRIPT_DIR/libs/contracts/enums.py"     "$ROOT/libs/contracts/enums.py"
copy_if_new "$SCRIPT_DIR/libs/contracts/base.py"      "$ROOT/libs/contracts/base.py"
copy_if_new "$SCRIPT_DIR/libs/contracts/errors.py"    "$ROOT/libs/contracts/errors.py"

# lib stubs
for lib in db authz storage feeds datasets audit jobs quality parity telemetry utils; do
  copy_if_new "$SCRIPT_DIR/libs/${lib}/__init__.py" "$ROOT/libs/${lib}/__init__.py"
done

# service stubs
for svc in api auth orchestrator scheduler market_data_ingest feed_verification \
           feed_parity artifact_registry alerting observability; do
  copy_if_new "$SCRIPT_DIR/services/${svc}/__init__.py" "$ROOT/services/${svc}/__init__.py"
done
copy_if_new "$SCRIPT_DIR/services/api/main.py"        "$ROOT/services/api/main.py"
copy_if_new "$SCRIPT_DIR/services/api/routes/__init__.py" "$ROOT/services/api/routes/__init__.py"

# tests
copy_if_new "$SCRIPT_DIR/tests/__init__.py"            "$ROOT/tests/__init__.py"
copy_if_new "$SCRIPT_DIR/tests/conftest.py"            "$ROOT/tests/conftest.py"
for d in unit/controllers unit/services unit/repositories integration acceptance; do
  copy_if_new "$SCRIPT_DIR/tests/${d}/__init__.py" "$ROOT/tests/${d}/__init__.py"
done
copy_if_new "$SCRIPT_DIR/tests/fixtures/README.md"            "$ROOT/tests/fixtures/README.md"
copy_if_new "$SCRIPT_DIR/tests/fixtures/generate_fixtures.py" "$ROOT/tests/fixtures/generate_fixtures.py"
copy_if_new "$SCRIPT_DIR/tests/acceptance/test_m0_bootstrap.py" "$ROOT/tests/acceptance/test_m0_bootstrap.py"

# ── 4. Generate fixture CSVs ─────────────────────────────────────────────────
echo "Generating fixture CSVs..."
if [ ! -f "$ROOT/tests/fixtures/clean_ohlcv.csv" ]; then
  python3 "$ROOT/tests/fixtures/generate_fixtures.py"
else
  echo "  SKIP: fixture CSVs already exist"
fi

# ── 5. Run M0 acceptance tests ───────────────────────────────────────────────
echo ""
echo "Running M0 acceptance tests..."
cd "$ROOT"
if python3 -m pytest tests/acceptance/test_m0_bootstrap.py -v --tb=short 2>&1; then
  echo ""
  echo "  M0 acceptance tests PASSED"
else
  echo ""
  echo "  Some tests failed — review output above"
fi

# ── 6. Git commit ────────────────────────────────────────────────────────────
echo ""
echo "Ready to commit. Run:"
echo "  git add -A"
echo "  git commit -m 'feat(m0-s4): green -- repository skeleton and tracking structure'"
echo ""
echo "=== M0 Bootstrap complete ==="
